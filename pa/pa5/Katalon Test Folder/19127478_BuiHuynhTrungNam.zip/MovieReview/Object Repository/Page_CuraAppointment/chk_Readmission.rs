<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_Readmission</name>
   <tag></tag>
   <elementGuidId>6d3987bc-b833-49f0-8d4e-19270fcfac7e</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>hospital_readmission</value>
   </webElementProperties>
</WebElementEntity>
