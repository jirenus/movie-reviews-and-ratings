<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Appointment</name>
   <tag></tag>
   <elementGuidId>c255d16b-6f69-4f80-9054-e354f56604e6</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>appointment</value>
   </webElementProperties>
</WebElementEntity>
