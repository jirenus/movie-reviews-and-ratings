<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Comment</name>
   <tag></tag>
   <elementGuidId>b70ba152-d5df-4e11-9c8a-4730577f03f8</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>comment</value>
   </webElementProperties>
</WebElementEntity>
