<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Login</name>
   <tag></tag>
   <elementGuidId>71dffcc0-9487-4a38-a94c-ad6b2c1c35a1</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>btn-login</value>
   </webElementProperties>
</WebElementEntity>
