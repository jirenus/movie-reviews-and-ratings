<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Sat Dec 25 2021 033316 GMT0700 (Indochi_3135f1</name>
   <tag></tag>
   <elementGuidId>884fbd6e-eab7-48bc-9888-17e6ed8faf7b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.blog__details__comment__item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Anime for Beginners: 20 Pieces of Essential Viewing'])[1]/following::div[19]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>blog__details__comment__item</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                        
                                                
                                        
                                        
                                            Sat Dec 25 2021 03:33:16 GMT+0700 (Indochina Time)
                                            Viet dep trai
                                            Good
                                            Like
                                            Reply
                                        
                                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;blog-details spad&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row d-flex justify-content-center&quot;]/div[@class=&quot;col-lg-8&quot;]/div[@class=&quot;blog__details__content&quot;]/div[@class=&quot;blog__details__comment&quot;]/div[@class=&quot;blog__details__comment__item&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Anime for Beginners: 20 Pieces of Essential Viewing'])[1]/following::div[19]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div</value>
   </webElementXpaths>
</WebElementEntity>
