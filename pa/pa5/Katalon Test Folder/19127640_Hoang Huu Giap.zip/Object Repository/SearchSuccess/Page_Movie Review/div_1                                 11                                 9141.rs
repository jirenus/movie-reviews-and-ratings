<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_1                                 11                                 9141</name>
   <tag></tag>
   <elementGuidId>8160f9a9-a2b4-44fb-be7d-80545147e5a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Result for: man'])[1]/following::div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.product__item__pic.set-bg</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>product__item__pic set-bg</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-setbg</name>
      <type>Main</type>
      <value>data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBQVFBcVFRUYGBcaHBoaGxoXFxgbGhsbGhobGxoaGhobICwkGx0pIBcaJjYlKS4wMzMzGiI5PjkyPSwyMzABCwsLEA4QHhISHjIpJCozMjI0MjIyMDI0MjI1MjIzMzIyMjIyMjIyMjIyNDIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAgMEBgcAAQj/xABGEAACAQIDBAcECAUDAgUFAAABAhEAAwQSIQUxQVEGImFxgZGhEzKxwQcUI0JSYnLRgpKisvAzwuEkc2ODo9LxFRZDU1T/xAAaAQADAQEBAQAAAAAAAAAAAAABAgMEAAUG/8QALhEAAgIBAwIFBAICAwEAAAAAAAECEQMEEiExQSIyUWFxBROBkUKxM/CCocEU/9oADAMBAAIRAxEAPwAbjx9lcP5T8Kr7g5WPLL8KL3rzNh3zCDoO+SNfWmdnYcurIBJZlUDmToN/fUW+LNFCcBfIAk8N9HsNfnQ//NRBssiARlYEjKdzQJgcm7OPCo1hyhgz8xSunygQk4upB1xpTMV5avyIPnTkUhcaIpIFOsKQFo2A9Ar2KUBXoFCzjyK8inIr3LXWEaiuApzLXBa44j33ygmoQSdTqeXKpeOXRe8fGvFXeTE/KmvgVjDWt+gPKm/cOh04jl21IGbfGnDn40m6uh04a/Kus4fQzXEUjCjqjupwiuOEEUginSKQwrjhtjUawzOJlR3g1JYVBwm4jtNEA+1m5+X1pJt3Py+Z/alpcPP50hL7O5AIAHZPh8a44Q/tBvC+ZrwG4dwU+NS8QViGnXkD8qasuo6oB1neD8aJwzbcmZEEGKcBqK+JRXYMwGs+lSQa4By76dUU0u+n1FcFHor0CvQKI7K2TcvEkdVB7zncOwczQD0B4FLUVX9u7VdbrJZchFMAwpJjiZFQMP0muowFzK6zqYho4kRp6U2xi71ZdFFKivLbAgEGQQCDzB3Vz30BguoPIsAfKamUAbrGGf8A7gA7sy1J2EGBBUEsLkgDmIIpjEJlsKObg+ZJ+VWL6P7QN63P4mPkpoy6E11D1s28QvXAVjAmOrMmQw4HX9iKE7V2IynreD79OT8x+beOOmtXXaWwlYlrcI/L7rT/AJuoXaxDIfZ3FOn3TvHahO8dnkalzBjVHIuChNae2crDw+Y5ipWHvToatOO2QjLmTrJwA3rzy8u1fhxrl/BG2dd3Zxj/ADdR3JnRi48HrCkqKmPapr2dGx6GwKUFpxUp1bddZwzkrslSslNXARuFCwDWSvcte525eorzOeXqKJw1fw4YQahAQQraNPg0cR+1EjcPL1FN3DIgqCO2KNnEZjv7NxO7dUYjOYXszHhpwFSfYW//ANY89PKaczx934V1gPFtwIrorw3ez4Ug3uz4VxwoikMKSb/ZS11ogGiKgYZdWHaaKFaHYcfaOO0/GicRXJ1iQBpA3CfmamYUDqkACYmOe7dXmLuN7oG8ctf80qPiXVbfWnWRoYrrAkEcSoiZgg6ECde6h+JvrbQsCSw3SDGY7zHnVeS8VMoSvdUi5jA9vK3vDcRx5z27/M0yAyNjHLNmJBJEnL8+2imy8fmi2w1AgHnA49tCzhbh3ITIkd3OiGzNnMrB30jcOPjTMRXYXXeKlKKjKNRUxRSMohu8+VS0TH7xVxx2Jt28Ki3CoBtgBJEBsokuJ1JJ48e01XdnZPa2w0EZl+Oh84qF0/2PbtYiwbChGvsbboNFLPorRw1MntUGjFCzYDwnR65i7kWIymeu8qum8xBMA6d4PLQV0p2C+DfI9xXOgJUECSA0a99Xb6PekWGtq1u/cS066L7QhVjiMx0kET25j21T+nW2beIvH2bZlDMcw3EnQRzAA39tOrJNItH0dJ9YsOms2VYA8CTJQTy/avOjWzslhTcSbjku2cHNLc/ACouA2ydm4CzathTisUfaknUIjHKjEcSVAgdreNqFs8NeZ5niaWXBXHyVjaQ+ztD8w/tarN9HKfap2Kx9CKre0llbcbgGbyAH+6rF0Hw9xmb2TBWFs5SdwOZezlNSfYKXU1COHbuO7dwodjsIlyQwnl+Idx41GTaV+0P+ot5h+NI7tRu+FSsNjbdwdRw35Tow8DrQyUxI3F2QxhFVlyzO4mfegfeB40H2thxniImDu36VZbg6y/xd+7130E2j/qR3fAcDUqo0wd9QS9imTZom4pGQUbHISWKdWxU5LNOrYrrFZANioWOtQDHZR82qiYuzodOHyo2K1ZXDZbmfOkm0eZ86ObPwBfcY/UYHLfIognR1juZf5j8mp076EnFrqyntaPM+ZptrZ7fM1dj0XfmP53/emW6MXeU91w0efQH/ACKY1s9vrTTW25H1q5//AGvdO8MP/NPyBrOelu1Hs3XtWiwKEq5YlpaYIG7T1or4Or3JS3FYkK6kjeAwJHeJ/wAmowxqMAQ6wSwEtElfeGvKqDdusRE6DhupqaqoE3I0pJIJGo58KJWB1RWb7I209gFYzIfukxB5itIwZlFPMTSTVFYO0KIobZH2rjtoqVoXEXz4fClQ4nag6oMnfHfp/wAVI2ZsgXlDvmyopJgxxyqJ36wT/CaXibQYEEdo76J3NnO+BtIgAuMRB4aNEHwnnrSZJUh8cbkVDE7Ots26I3Qdwmgu08MLbqBJBHHvo90iwKi5cRF9w5YG4soAYidwJBPZNB8fYEKvLxgEjXu302N+4csetIbTGXFiDECOG7lTo2jcH3/Rf2qagw6sSpX3eZPEc6fS9ZjenkKtZlr3Bo2nc/H6L+1LXa938Q/lX9qJe1sTvt/01D21irTBVtKNCSWCgTpEc65P2Cvk8Xad+6RbU6toAoAPnwHbVo6EbVt47FH6yTcvWFDWHkgEDqu2QCC2oMkEwZ0IqnYpvYYU3DpcxGa3bHFbSmLr9mY9QdmehPR/a7YTEW8QgkodVmAykEMs8JBPpT0JOXNEnpLhfZ4m4IgEyPHtofhMN7S7btje7qk/qYLPrRzpntbD4i6LtnMMwGZXWGVogg8DuGoPGh2wLbZrl4brFtrhJ3ZiMlsd+d1PgeVcugj6iukG0Pa4t7i+6rBbY4BLcIgHZCg+JqxW+mNwiYTyP/uqlWxT4tmuaTCpNGhbT0AH5GH9SftVz+jZOs55IB5kftVI2nMgHWE17y3/ABWgfRymlw9iD41nfmRd+Vl4aqNtnbezkuMrlluLOttT7w4SumbvijnTDHNaw7ZWys0ieIWOsR27hP5qxO7YNxiLcnv7THDtIFGfLoXGuLLzh+ntsXAId0EgG5lVtY5E8t5NFl2jbvsXtkxpIOhBgbxw3Vm2B2ZmdRmMmCIWRrJEk/pbhwoj0dxVy1ifZT7xKlWOhI3QeBjce4VNxVcFotp8ovj0kCnHFT79pbFo3GXOxGi6QNJkzppSJWPKVDViwxE5THODUgWjvism2jtXGe0N03LgWeBYJB0AjQEeFEtg4u4GD52LDUyTr2HnRqhWzSMlRsVb0buqahBAI3EA+YpnE6AmgwJ8iNgQJ1gwNxUHeOBo9b3cfJT8KF4DChxqSNAdO2po2cRub0qsE6tIlkcW+WSCo7PFDXmUc19R86Y+rXRucHzHwrwi+OAPj+801vuidejJGXlHg7VgXSm09zG3UQZmZ2GVDoSGM6nhIJmtxa9cG+3PgD8BWRlGs429cZfcF2NI3nTu3illIrjj2ZSL/R28GIOQEfmPyFRbuwrqj7p7ifmKtJxLO7MxEkkwo0H71BuYgkkBz3FQR5jX1p1OQ8sUSp3LZUwwgjhWo9FXL4S2SZMEfysQJ7YArOdrf6ngPnWl9EMIEwluCTnGbXhm4Dspsj8KZLGqk0EGShbnLfkiZj4UcdKhrhZu+0Y5baKC7HvMKObHgKimWoi3HIyyPemJB1jfHPfVm2Ti81gFwFCMddYyooaT60B2xdNxRcBUKly3CBpyJLKBpxOfU0XdHt4e4BOcqxKg6gRoPL4ilyJNUx8dp2iiYzFZ7ly5OjMzCd8Ekie2h6MC0sJHLnypvEYjSNwG8n/NaiLisxgHKNwnjVowSBJykm0FHNo7rY3fOmHVfwAefrTMPzFd1+Yqhms8e3yA8zUvYGyWxN9bQ6q6tcb8FtdWbv4DtIqGQ/MVoeDs28Dsp8Qdbt1AxaNRnH2aDsXNPaZ7K5nNmb9M8et3FMLelq2BbtqNyomgAoDS7SM7BVDMzHQAFmJPIDUmrLY6AbTdcwwrAHWHe2jfyswI8QKfoS6ld6upZjPJR8yavm0MBbwmxgphb2Ke25U++UU5lB03AQx4S0UA2b0buJi1t4u09tEBu3cw09lbGZirDRgdFkE6tUTpBtq5jMQ159J0RBuRB7qj58zNBnIj4a1xqXlpGGtkinLhAMTROLltLee5B/UxrR/o9X7O4e1R6Gs3x51/jUeSz8603oDHsX/UP7R+9Zv5I0PyP/e5N6X4Br2FdE3xO7UhQWyjvKrWT9HnAxBDmM6kCRxMFdOWlbnc3GgGN2HhCDcewjZE/CJypMAdup9OQrsi5FxTpclV9iMvJiBJWB1t5iRukneONCrOG9pjy6r1FgMRuDBSwjtDKvlRHGbURnJtyF6oVYEht2Ujnm0nd276f2VtH2lxkgGPvT7x3E+fGpJSV8GuTjSCp31N6YYrLhHKRIOXUxoHVW1g9lQmoV0guM9p1IBFt0fWTmR0KNI4gNHmK6MuGhXFyaa7FXa/7RCDEdhkfCvNjX1ByyARwnt01pGEsW7YInfJ101pAw6B867yI7ImZpuOUNKLaTZqWynm2BEFZUjlqYpWM91v840H6PYtnuRzDz2hVTX0UUZxw6rUnYlVSCGyBoe5aJ0P2WND4UQrVi8ply+ZnldXV1OIe1n/AE3wKe0dwpzG1LQdG6wXdwMKPStAoF0m2fntsw95VPip3jw31PKrjwVwySlyYvdsQWuMVUSQqiJiOQG4c+ZqDhl0Gq5VLZhHvSI63PsgipO3EFsj7NidetlJHcKEJiOqQFy9kRU43VmuSXQj38Er3VUkwcqyO1tfStZwNgBAANAI8qrvRno8ptpiXJLQxCQMuk5W59vlVqwPuedCUr4FUUuRPspMUxdte2CqFOTeq89PebmxHlSbQZmmW3kAZWjlvGgoZtLC3FcBLhAQBJBMZgOs3fMxyAFJKW006fTPNLbdCr7W7eZFiSQGO8LlaRH5pG/h37vds7WRMMwVhnZYXXrAk6kEdg176rO0pB97Thwk0KtsztqZyiaG3c9zPW/+eEIqKBt1iTrScvGpj2xNMEaxWizK8G09t4hhpOlOi43OmGQCkE8RTKRiy6Tm06YT2XYa9etWp/1HVD3FgCfKa0z6QsBdv2beGw6Fi9xF0Byoije5+6o5/Os/6JLca9bazl9qHCrnBKrmVwzkaSAJbfwrbbd4KAubMREsQBmPEwNBRbPPlFp0ytbD2TgNlIA9xPbEde4/vtP4R9xOQ7NZp/G9O8FbMG4xncVQsPMaeFA/pVwPVtYgf9tvHrKf7vOsyczpRSsS6NW2x0j2fjbFyw10pnEKxDKVbQgnmJCyNxiseXD5GIbeCQY3SDGh4ilXla2xRwQymCDoQQYg0h340yVCt2TBisqxQu7dJJNKd6aonWaPjT9pH5x/YKsmysBif9S2jhSNGWRuJB18Kq10zc72J8oHyrR+jG2XS0iMgKAaHUHV247jWSdXyaVdWj21tbFIIYk/rE+v/NGsBjTeDIwAzIdxPZw8Tx4VIO0LTjrLHeJ9RTTJagshGYa6H5UFw+tgk1TtUZX0jw+S6ZEawY5jj/nKn+i1w+0bsX5iPhRnp3hw6276DRgCe/c3iCAPE0A6Kt9o4/J/uH708peFseCUqXYvbNOu6da9S2GBVhIYFSOw7/8AOyomIuFYA5UnE4trQGb3yuYAghdd0tzjX/NIxTk+CrpFP21sq5auZDEb1Yicw4Hs7qJ7I2I121cuTqgAAHEsdfADWmcVtH63BeVuIArJoCscSO3fPbRbYm1vq7JaCkhyxZvwwEAJ7NW0qux9xpN9F1LPsfAC2ociHdVlY93SSPEn0p7HDqmotrH3C6qwXrHhPprUjaDQh7x66VO1XBGmpJsJ4JwoMmN1SfrC8/jQ7Zg9opZt8xp3VN+qL2+n7VeDe3gzzS3cjhxK8/Q0k4tOfof2pH1Re3z/AOK44Re3zprkLURX1xOJ9D+1eNjrfE+hpsYRO3zrjg07fOhcvYaoe5lnTrApbuEpOUjNyjWI+FZziDqRw51sn0hW7KWgeIBBAMmCyx3SQaxm/iJYwAASYG+OzWpq1wehix/cim3X9mi9GekK3ra2cp9qFbNuC5QvvD007asOytw7x8axO1fZGDoxVgZBG8GtW6F7YXEW50FxCA6jt3MOwwfI0rjXIckFGqLHsXKFf8QLRpzk6UBxNowY0mTrwgx8Zqf/APUvZBvZ2y7yRMHKNdRpvNBsTta2GvWLpIeW9mzTlZXJYAkag5WA7dNRXfZlkTcVdDafUxxTqXFuvyUbbWJBYhd3PhqdPP5VAwT6PvkZRPCWJ/au2m2Z20jhpyid513zUbZgBW51iCII1MHQ+um+qRilE2Zc8lnSXuv0iTduyAedR2pbiAKYe6Bxpoxb6I7LmjHzOh4mmnFM/WeAFOo0iaaWOUVbM61UMr2p8lk+jzE5MaoO51cD9WRgvxjxrTDjxbgObYLahbrZcw4QeU9h7qxjZxIdnUwyLnU8iHSD61p2K2+b+DuQ6lntlWw90ZQDGvs7gWDIBhW8xBpTBqFUgB0svXS1y1ku2sO5VlGc3LZIgkgsSBrrCFSNJGtVLDpct3bdzJ7UI6PCmcwVg0Rv1iN3Gid2/csWWa3aa2GBVs8MsNp1QSVnTeBIqt4d5YAMQSQOO8mqIyssGP6PO4z27i3LjDPlUtm62pRswHXBJHeI7gN/A3bZi5bdJkAspiQY0bcdatGy9pKjXG3kW3CzwO4HwE1LwvSV7YVdCMskH8xLfAiusFFBGte5a0HG7Rwt1Qz4W2zBuWXeNdVidwqNmwH/APInm/70bOocwtwO4I5sTPCTpW37FwijD2hlHuLw11E/OsTwNkK69ok7uZHDdurd9nLFtByVR6CoJJyKzbURq/s5Dwih1zZYXrq26TqOzWjtzdUPGe436T8KE4pPgWMm+GUu5aUpdwrMC2txOBCtGYR45vAmqp0ZUi5dJHu2yW7IdR8TRPpRj3tY0XFWTbybzowyCV7iJB76Ivs+3be5dtmVvIIMqQASrnVZEyonXtpXwue5pj1Vdh67tBbMW2WbqKgdzqAxUMQq8ImJOunCh1/GhySxLE1G2xdLX7rc3fyDED0qt9J8e1qyGUw5dQPDrHw6seNWUF2I72uodxFlGOZZVhoGESOzu7N1eYBGVizvnYwBpCqo3ADx1NQ9l7QW/bDrv3MvFW4ipiGjXYKm6DeG2iyEQdxmCJHlR98V7WyHiJYAjtB/w+NZpd2jGPRJ6rWoj82ZmB7+qR41oOz1jDr2uT8vlUskUojwdsO7PwbZQwaAdY1qZ9Wf8XqacwHuL3VINNGK2ozzm9zIXsH/ABeprvY3PxepqZXUdqBuZBNi5+L1/wCKibRuXbaM0yRoANZJ3cN1GaB9IgxAVWCgBiZMbwR6DMaWcaTqymF7ppOqMz6X4gnqFsxnMzHizKG9FYActazi8ZY8tatm2cWLiXbnO4YHIN7o8AAPCqgVHpW3U41jxxS9Culm8mSb+BDaTHAVa/o3xWTGZJ0uIw72WHHoGqpMu/v/AGox0VfLjcOf/EA/mBX50uLGpY5N+gNRkcckYmuYQ9Vv1v8A3GqN0yE325wp/pAq74M6N+t/jVF6Xn/qWHNV/tBp/pf+SXwZPqV7FXqRdr7PtJldWMkKYidSM3PdVfGGySAe3/PAmrbi8IPqlpy3WISAewMBHOYqq321rC7UnH0bPpoqM8UMj61/4RMXcJgVDJp7EGWpg16eNVBI+b1c92Vv3PRvqRhzoaKdFtki+bs/dQhf1uCFPhB9KE2Jkzy+FJNqUWvQbT3DIn6kvBqCzT+BiO8CflV52ThTctx+K2nAHfmG4iOFUnZ4lz+h/wCw1pfQxJS1+hB5XHFYW+DZmS3fgp2N2TcuW3a2r3VBIGQBhKmCMq9ZT2HdVVtIyXFzAghgSGBB38QdRVn2pti5g9p4r2R6jXWLI3utJzbuB1OtHcbtfD46w9sFVulTlFyAysNRlbiJG8axwqnQxPkzyxfIzT+E+cilXsSZEcl9FFSMXsi5aBNwCI3qZHZPH0qEdf8ABRFJNvHMFM8x8DSPrxpiNK72VE40HCL9ogiNF4zv1n1reLGigdg+FfOD3CLgUE6MADOumgrdOi+Pe6rl46rBRE8p4k1BUpfJeauPwG7lQ8eeo3dUy5UHaHuN4erCkl1YkOqMm6ZXD9au+7owHbooFB8GtxiEUtBYSFzEb95A0rX9tYVPZs2Rc0r1sokzv1qq7MM3G/UPjQeSuKNMIbldgvHt9rdP53/uNUrptdkWl4HO39oHxNWfa13UqPed8ojgGYAnwBqj9Kmf2qo+9Fynt6x63iMprQjPNUrI2w9qNh7gbehgOvMcx2itDv45EtG8W6mUMCOIO6O0yKyqpTY52tLZLdRWLAdp+Q1j9RpycZUHdiYhr+NFxzG9o5ACFUeY9a2+0kWLQ7J8wT86w7YGFZEF/WC5QaTJTIx/vA8K3Fbk2rBG4opHilZ83Q1Y4tUw0zXFsg2wpIWdZMxwAEVB2PtssjPeKqAQFO6d88dYohexQt2M54LPjwrLto7Qe45Zj3AaADkBwpZS21X6LaXTffUk1xfXv8Gp4fatlzC3FJ4CYJ7p30IxvSRlum3bQNBjjJI3gAVnCYrUCde+r/0HZGRjlGcHVt5IO7XhuNBZJSddB8ujhgi5vxexY8NddlBZCh4gkH1FVTpfisq3W1hEy+LKFA/9SfA1cINZL9I2NLXyg3KY8cok+lVSuUU/VGTD/JrsmUW65IZfxMp8YahN+zlYqeE/Gjmz0BuAtuU5z3KCaB37hZmYk6kt5kn516OvfhiL9PXikyOR8aJ7AE4vD/8AdT+4UOQUZ6JWi2NsgcGLHuVWPxArsUduBv1sjqJbs6S7Uangzo362qpdMUQYvWZW0hI/OV6oPgQfCrfsxMzFedw/KqjjMMcW2Lurq/teoOBVQ4C9nVy+IFZ9BJQlKbdJKv2PrYPIlCKtu3+iJtNycLZE/d3bjpmA76rF7fRzGMTZtA6Fc6kHQghyIg8dKr+IbQ1navI/lnuwlt0sG30SB9wyTSKVFe+zNeg2o8Nnze2eR2lZePo6TqXj+ZB5An50A6QYT2WLuLwY517n1+OYeFWroHh8lhz+J53clWoPTdFN22R7wQ5u4v1P99Y/uLfKujRthjdxXdNALZKzcP6Ln9hrSfo9E27X6W/puOazjYom6P0v/Y1X3oNjVtYZrrbrVu+5/gIaPHNHjUS+o81+wFxWCw9zGl267NicTauZtUGSwMhyATJfMQZ+4fCn4jCNL5SrBWy6TrxBAaDGvGj/AEFz4m61lz1Q/wBadtcxKqyMvLrG6Nfy8aC53NwqIAbO+s6ZEJPolVMCON0+yy6yQN5PiI3UOuAcgO6pkyoqK4rkczxKXFeIKXTChkNN/wDj/wB1bd0Ik4e7lMHOQDyORY9TWEW7h9pmG/NPrNX7o90hxqo9uzbDBiWJW2zkEqF04Rpy51nlw0y65i0XvoXtpsRacXHzXEchgYBymIMDhMjwoztA9XvZB/UKyzobtZcJin9vKBlKNIMq0giRvG4+dahjDmVcuoLIdOW+e6psPFg/pLehEXhqx8B/yapOzMUqMznXKjPA3nJ1j6A1PxO07r7TWyXm2HGhUaKBnI3TFStrQtu4AU60jQiRLDgOEZqFXL5LKSikr/1lE2Zmu3jcZSVQEyAxCkkqokab9fA0O6c4XMLdwAyJVtCNNCPiaOdDrht3btsn3kCwo3smVuX6/Oo30mXWS1YXUe0NwmfwoUC+Zzfy1ole9JAy1tM4pSGk16KqYS87PdW2fZC70u3Q/YWhlJ7CoHkavnRXHG5hkQ77bMu+dCJXykj+Gsm6O3W+2tjVWTMwkgSrAKfAO3nWj9Cv9O4dNSGEeHzY1HJHws345JwRo+08MbmEZRvKyO8ax6VRNl2LTYfFl1UsqEgkAsvVYqVJ3HMOHZV82lm+q9UkMVAlfeA0LZe3KDFZVtHEiSAwYZVztlCnMQGZTAEw34tdKnLhp+xfRpzhKF97D+27VuzgrNoBfaOVcmNZiXad/EL3GOFO7AvPZsl1aC5BA/KJie+TVWwlu5eZSczLouZiSAo4Bjy10FWrFXgVgbhu7qeEdz3D5l9vH9u7bdsu+yccL1sON+oPeN9ZX07tf9Zd8/NBV76DXJtXByf4gftVQ6eJOLvaH3VP9P8AxRi6lFv1MmCPinFejoztruVLsb2UKPE6+k0HuSBu/wA3UTv4xMhVAczEEseyYCjgO2hl0/vWjU5llkq6Ipp8DxQk5PliVq5/R5hJe7eP3RkXvPWb0C+dU01ofQg5cOn5i7Hwcj4AVq1T2YUl7I8zB48zk/dlmwF7J7V/wZ28lmqF0c2mLbMj7nIg8A2o17watWJxAGHvtwII/nhfnWdYpco05zWfRxhkjPG+9f8ARq1P3MWzPGqTr9lh6SPJHeDwjUaxxO6qvcUHfU59oZ0AfhuPPv7e2oF68o7T2fvUFp545VR6j1mHLjTTVej7ewnL/gppmHE01cvE9lMmrx0z6yZ5+TXR6QRe9jYHFNZR7F9URpIUrxBKyZU8qA4+5cZrhutncOULaf8A4+qIgDTWrb0JecGg5M4/qJ+dVTaoh7n/AHbv91Z2qtD6fxTUn6NjWys/tPswM0NE7t2vpNFL+OybLuIPeuXfZ/wwlxv7FHjSeiViWuN+FCPEkD4TUDpHbyWMKp3v7a6R2M4tp6WSf4qEOWLq5c/gOfRncW1bxd5v/BQHnLO7AfyLVdx2VLhj8NwD+IFfnUzD3vZYC0Adbl67cPcioig+OfzoNi7mYz2fOn7mPsOp7o7qjuKftHqCmrlcjmIFSbVmRNRQNaP4MIqANvpgDWBtlb6BtOsp7InfW6/R9H1SRxdvkPlWLXMS9woIUQQAY93+NpIG6dYo7i8biMEESzjCVcZyiM0qTvzKRAzb9O47pMmmmmW7NF12r0RV8Y9+48W3VmlSAyXBlCkAznB1MRHAzNWrC4qEDFXaQFJyFTKgy2U7geznVE2Ptt7GHtqllXu7mcZGbK3WBZiwOkqIJPpVhtY+4Al666oh1UXnVJ04KgPPfJqVc8DNccggXEG287aArpMe97EaaHlOtN7RwtxUZmQhZHWlSJLabjPGhu0NrAYv6yqC6c8/ZyysmRUyyV0Iht44jfrRza+MW9ZVkwz2tcxzIq6ZTvjU7+6jXI3x6FSwlnJjFuKFjK7EsQomFTf3Gqntfa/1o3kc65zcsmdARMoO9Zjtq4bRvtas3bgA0XLmI3FtBHbJ9KylzrNVXLsnkm9qQmvRXle1QgTMHivZq0e82Ufwq2cjxZU8jWvdE7arlQQVKyDJgg9dTzgiDWLqa1boNig1rDsd6lrTfwnq/wBFxB/DU8i4orjkaFexzZcrEAAGInmq+OjVQdqY03XyuYSSCocwYbTMY/Eo1jQVZNtMAoZe0ecEfCqdtUBiOGgMiBJzFj6k0kYOUOL/ALPS0zhF81+XRLwGMytkzErECeEaAAcBAGlEHvSDQHCESTx0ipvtdDVowcVTEzzjKTcf7sPdF9qPbFwLlgsN88jyNVfpx0hdsSYIGVAjZQYMknrTvgHTlRXZVxbdm5cb8RjtgCB5zWc7RuFnbNvJJJO89vjWWXMmi2kik3LvXBBYTrPlTaid9LYyaTNehpMO57n0Ri1+eltXVnhNX/olIs2u1X/uY1n7VoWxLiJhrfUOfIMrEmJOp0BjnzqmvfgXyYtGvE/g92uScI8ECHUmTwHLmZiqbjn0HcPhVg27jYtmyJkwx3RAJgd+gM9tVbEN1RUPp9qcn7G/6jxpoRfd2IV5Uio7V2aK5WmvSct3B4yjR4VpFPXFpikmqGi7NF6D3AcLH4XcecH51XdvIVuODGru+nJmJHjFG/o8uD2V0HhcB81A/wBtBelFwNfMcFQa7/dH715WR1Nr1Pa0iuO70VBfo5etW7BL3EVnJMFhMDQab+fnVW6RYpHa2Ez9RMjFzvb2lxpTUwgDqBu3HTWvRUbah1tjgEnxZmJ9I8qMY0ZM03Jk3FPGFwo/LcPndcfIUKZ5qbtO4PZ4ZR921r3tcdvnQwmmIsI2PcHj8aS1e4ZpTzrjQGOtLJqTefWmrC8aRcfWmFDdi5CEwCQy790AzuOhEqNCKTfxHtHLu6gnfliOWg4d1dXUj5KyJOJ2iwgLincRGmdQOwSf8ipuxMJdvBmzKwBjrZXM7/vNpwr2upJ8LgMepa8FhrllGZUtyoJLZLc6Cd+eRu4VETpW9z7K4i9fqyOE6Tvrq6px5KMrHTPabLb9gIyuwuE8Tl0A7p1qimurq0ozT6nCva6uoinCtA+jy79ldBPuXLbj+IMD6IPKurqWXQeHUu2PxCqpV9QdwG8jgR2dtVvaFoZUZWkarugjWRI8T5V1dRwSeN3E1rHHI9suh2BwTsUAB64nNBgb4+HrU99jXBOqgcSZAA7SdB511dQnNybbFUVF7V0A+0sSDFm2ZRJEj77E6keNANouuqlRI01Go5gV1dR0UIzl4hdTklBeEEPypsrXV1e3CK2nkzk3Lkaerf0WcvZhDqhIOsGCSw7x+1dXVg1vlRp0vmB22Lh9u8nUQv8ARG+hGI4DsFdXVn0Xc9H6n/jgRGry37wrq6tv8keV2H79Rq6uo5OouPoG9gYxraXSrEaLuMfiAqJeulmLEyTvrq6vKzednv6TjCvyKqHtE9YfpHz+ddXU66Hm5PM/kbxDyE7EA9TTFdXUSZOwR6niflSzXV1KN2HA0LUUGda6upgH/9k=</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                1
                                 11
                                 9141
                            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;product-page spad&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;product__page__content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-4 col-md-6 col-sm-6&quot;]/div[@class=&quot;product__item&quot;]/a[1]/div[@class=&quot;product__item__pic set-bg&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Result for: man'])[1]/following::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='man'])[1]/following::div[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Movie'])[1]/preceding::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Comedy'])[3]/preceding::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div</value>
   </webElementXpaths>
</WebElementEntity>
