<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>SearchFailed</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>0f199809-e5fa-4339-b657-84223fba9caf</testSuiteGuid>
   <testCaseLink>
      <guid>d5b27d3f-0552-484e-8eae-220a8aad8ef5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UC04_UI08</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>de135994-ed24-45b6-a601-4a9c8e167461</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/SearchFailedData</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>de135994-ed24-45b6-a601-4a9c8e167461</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>value</value>
         <variableId>cf6f4f0e-a1e1-4fac-8de7-1cb7a412a0a2</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
