<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>SearchSuccess</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>53ed23fb-1f42-499f-ada9-6b6a1172f819</testSuiteGuid>
   <testCaseLink>
      <guid>b789fee6-5a3e-430f-b569-9893a4cd8f5f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/UC04_UI07</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>3e475e09-7155-4139-941f-a90b8361dd5d</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/SearchSuccessData</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>3e475e09-7155-4139-941f-a90b8361dd5d</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>value</value>
         <variableId>be733e9b-06f1-4fb4-a3b1-63475aa8a6d5</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
